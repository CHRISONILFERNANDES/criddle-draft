'''
This file stores all the functions used in main.py
'''


def word_checker(entered_word, iword):
    "Used to check the letters of gussed word matches the letters of iword."
    cl_list = [] 
    for i in range(5):
        if entered_word[i] in iword:
            
            if entered_word[i]==iword[i]:
                cl_list.append('green')
                
            else:
                cl_list.append('yellow')
                
        else:
            cl_list.append('red')
            
    return cl_list
            

def points_counter(end_tries_list, gmode):
    points = 0
    
    if gmode=="easy":
        for i in end_tries_list:
            for x in i:
                #Adding points for getting correct letters in correct and wrong positions
                if x=='green':
                    points+=100
                    
                elif x=='yellow':
                    points+=50
                    
                else:
                    points+=0
                                
        points=points+(500*(8-len(end_tries_list)))
        
        
    else:           #Adding points for hard level
        for i in end_tries_list:
            for x in i:
                #Adding points for getting correct letters in correct and wrong positions
                if x=='green':
                    points+=100
                    
                elif x=='yellow':
                    points+=50
                    
                else:
                    points+=0
                    
        points=points+(1000*(5-len(end_tries_list)))
    #Adding points for unused tries
    return points

