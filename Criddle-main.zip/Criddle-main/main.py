import functions as fn
# import words
import mysql.connector as mc
import random

mc.connect(user="root", host="localhost", password="mysql", database="mysql")

gmode=input("Enter the game mode i.e. Easy or Hard\n").lower()
if gmode=='easy':
    iword=list('taunt')
    points=0
    #iword=list(l.random)
    end_tries_list = []
    for i in range(10):
        guess=input("Enter your guess:\n").lower()
        
        if len(guess)!=5:
            print("ENTER 5 LETTER WORDS ONLY")
            break
        
        cl_list=fn.word_checker(list(guess), iword)
        print(cl_list)
        end_tries_list.append(cl_list)
        
        if cl_list==['green','green','green','green','green']:
            if i==0:
                print(f"You saw the word Krinj Kid!")
            elif i>=1 and i<=3:
                print("Kinda ez huh?")
            elif i>=4 and i<=6:
                print("Average kinda eh")
            else:
                print("Close one gg")
            break
        
        if i==8:
            print(f"Oh no you are out of tries!, the word is {iword}")
            break
    
    print(f"Points Scored: {fn.points_counter(end_tries_list, gmode)}")
    
elif gmode=='hard':
    iword=list('taunt')
    points=0
    #iword=list(l.random)
    end_tries_list = []
    for i in range(6):
        guess=input("Enter your guess:\n").lower()
        
        if len(guess)!=5:
            print("ENTER 5 LETTER WORDS ONLY")
            break
        
        cl_list=fn.word_checker(list(guess), iword)
        print(cl_list)
        end_tries_list.append(cl_list)
        
        if cl_list==['green','green','green','green','green']:
            if i==0:
                print(f"You saw the word Krinj Kid!")
            elif i>=1 and i<=2:
                print("Kinda ez huh?")
            elif i>=3 and i<=4:
                print("Average kinda eh")
            else:
                print("Close one gg")
            break
        
        if i==5:
            print(f"Oh no you are out of tries!, the word is {iword}")
            break
    
    print(f"Points Scored: {fn.points_counter(end_tries_list, gmode)}")
        
    




# To do list:
# 1) storing words and correct 5 letter words
# 2) adding the option for 2 hints in easy mode and 1 in hard mode (will lead of reduction of points tho)
# 3) Ui ofc
